import{
initializeApp
}from"https://www.gstatic.com/firebasejs/12.18.0/firebase-app.js";

import{
getAuth,
onAuthStateChanged,
signInWithEmailAndPassword,
createUserWithEmailAndPassword,
GoogleAuthProvider,
signInWithPopup,
sendPasswordResetEmail,
signOut,
updateProfile
}from"https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js";

import{
getFirestore,
collection,
doc,
getDoc,
getDocs,
setDoc,
addDoc,
onSnapshot,
serverTimestamp,
runTransaction,
query,
where
}from"https://www.gstatic.com/firebasejs/12.18.0/firebase-firestore.js";

const firebaseConfig={
apiKey:"AIzaSyDhykFRKKt_Nt161SWDuNSWeDYDnO_H-xc",
authDomain:"fantasyxi-6e655.firebaseapp.com",
databaseURL:"https://fantasyxi-6e655-default-rtdb.firebaseio.com",
projectId:"fantasyxi-6e655",
storageBucket:"fantasyxi-6e655.firebasestorage.app",
messagingSenderId:"690112877933",
appId:"1:690112877933:web:6d8cd599dec36591b9f664",
measurementId:"G-1SRKVZ154"
};


const app=initializeApp(firebaseConfig);
const auth=getAuth(app);
const db=getFirestore(app);
const provider=new GoogleAuthProvider();

window.fxFirebase={
app,auth,db,user:null,ready:false,onSnapshot
};


let matches=[];
let players=[];
let playerStats={};
let teams=[];
let contests=[];
let joinedContestIds=[];

let chosen=[];
let cap=null;
let vc=null;
let role="ALL";
let selectedMatch=null;
let editingTeamId=null;
let currentMatchTab="upcoming";

let matchUnsubscribe=null;
let teamUnsubscribe=null;
let statsUnsubscribe=null;
let badgeUnsubscribe=null;
let contestJoinUnsubscribe=null;
let walletUnsubscribe=null;

let userCoins=0;
let requestBadgeId=null;
let isSubmittingBadgeRequest=false;


/* HELPERS */

const $=id=>document.getElementById(id);

function toast(t){
const e=$("toast");
if(!e)return;
e.textContent=t;
e.style.display="block";
clearTimeout(window.__toastTimer);
window.__toastTimer=setTimeout(()=>{
e.style.display="none";
},2200);
}


function esc(s){
return String(s??"").replace(
/[&<>"']/g,
m=>({
"&":"&amp;",
"<":"&lt;",
">":"&gt;",
'"':"&quot;",
"'":"&#39;"
}[m])
);
}


function showAuthError(id,msg){
const e=$(id);
if(e)e.textContent="❌ "+msg;
}


function authError(c){
return({
"auth/invalid-credential":"Email অথবা Password ভুল",
"auth/user-not-found":"Account পাওয়া যায়নি",
"auth/wrong-password":"Password ভুল",
"auth/email-already-in-use":"এই Email দিয়ে Account আছে",
"auth/invalid-email":"সঠিক Email দিন",
"auth/popup-closed-by-user":"Google Login বন্ধ করা হয়েছে",
"auth/too-many-requests":"অনেকবার চেষ্টা হয়েছে, পরে আবার চেষ্টা করুন"
})[c]||"Login Error";
}


function makeReferralCode(uid){
return"FX"+String(uid).slice(-8).toUpperCase();
}


/* AUTH */

window.login=async()=>{
const email=$("loginEmail").value.trim();
const pass=$("loginPassword").value;

if(!email||!pass)
return showAuthError("loginError","Email ও Password দিন");

try{
await signInWithEmailAndPassword(auth,email,pass);
}catch(e){
showAuthError("loginError",authError(e.code));
}
};


window.createAccount=async()=>{
const name=$("createName").value.trim();
const email=$("createEmail").value.trim();
const pass=$("createPassword").value;

if(!name)
return showAuthError("createError","নাম দিন");

if(!email||!pass)
return showAuthError("createError","Email ও Password দিন");

if(pass.length<6)
return showAuthError(
"createError",
"Password কমপক্ষে ৬ অক্ষরের হতে হবে"
);

try{

const c=await createUserWithEmailAndPassword(
auth,email,pass
);

try{
await updateProfile(c.user,{displayName:name});
}catch(_){}

await setDoc(
doc(db,"users",c.user.uid),
{
userId:c.user.uid,
userName:name,
email,
coins:0,
referralCode:makeReferralCode(c.user.uid),
referralCompleted:false,
referralCount:0,
referralEarned:0,
createdAt:serverTimestamp(),
updatedAt:serverTimestamp()
},
{merge:true}
);

}catch(e){
showAuthError("createError",authError(e.code));
}
};


window.googleLogin=async()=>{
try{

const r=await signInWithPopup(auth,provider);
const u=r.user;

const userRef=doc(db,"users",u.uid);
const old=await getDoc(userRef);

const data={
userId:u.uid,
userName:u.displayName||"FantasyXI User",
email:u.email||"",
updatedAt:serverTimestamp()
};

if(!old.exists()){
Object.assign(data,{
coins:0,
referralCode:makeReferralCode(u.uid),
referralCompleted:false,
referralCount:0,
referralEarned:0
});
}
else if(!old.data().referralCode){
data.referralCode=makeReferralCode(u.uid);
}

await setDoc(userRef,data,{merge:true});

}catch(e){
showAuthError("loginError",authError(e.code));
}
};


window.forgotPassword=async()=>{
const email=$("loginEmail").value.trim();

if(!email)
return showAuthError("loginError","আগে Email লিখুন");

try{
await sendPasswordResetEmail(auth,email);
toast("📧 Password reset email পাঠানো হয়েছে");
}catch(e){
showAuthError("loginError",authError(e.code));
}
};


window.logout=()=>signOut(auth);

window.showLogin=()=>{
$("loginBox").classList.remove("hide");
$("createBox").classList.add("hide");
};

window.showCreate=()=>{
$("loginBox").classList.add("hide");
$("createBox").classList.remove("hide");
};


/* AUTH STATE */

onAuthStateChanged(auth,async user=>{

if(!user){

fxFirebase.user=null;
fxFirebase.ready=false;

$("authScreen").classList.remove("hide");
$("mainApp").classList.add("hide");

cleanupListeners();

return;
}

fxFirebase.user=user;
fxFirebase.ready=true;

$("authScreen").classList.add("hide");
$("mainApp").classList.remove("hide");

$("firebaseStatus").style.display="none";
$("firebaseDetails").style.display="none";

$("profileEmail").textContent=
user.email||"Google Account";

$("settingsEmail").textContent=
user.email||"Google Account";

await loadUserData();

subscribeMatches();
subscribeTeams();
startWalletListener();
startBadgeListener();

renderBadgeFeatures();

});


/* USER */

async function loadUserData(){

const u=fxFirebase.user;
if(!u)return;

const ref=doc(db,"users",u.uid);
const snap=await getDoc(ref);

let name=u.displayName||"FantasyXI User";
let referralCode=makeReferralCode(u.uid);

if(snap.exists()){

const d=snap.data()||{};

name=d.userName||d.name||name;

userCoins=Number(
d.coins??d.wallet??0
);

referralCode=
d.referralCode||referralCode;

if(!d.referralCode){

await setDoc(
ref,
{
referralCode,
referralCompleted:false,
referralCount:Number(d.referralCount||0),
referralEarned:Number(d.referralEarned||0),
updatedAt:serverTimestamp()
},
{merge:true}
);

}

}else{

userCoins=0;

await setDoc(
ref,
{
userId:u.uid,
userName:name,
email:u.email||"",
coins:0,
referralCode,
referralCompleted:false,
referralCount:0,
referralEarned:0,
createdAt:serverTimestamp(),
updatedAt:serverTimestamp()
},
{merge:true}
);
}

updateWalletUI(name,userCoins);

$("myReferralCode").textContent=referralCode;

}


function updateWalletUI(name,coins){

userCoins=Number(coins)||0;

$("profileName").textContent=
name||"FantasyXI User";

$("homeName").textContent=
name||"FantasyXI User";

$("userName").value=
name||"";

$("walletCoins").textContent=userCoins;
$("homeCoins").textContent=userCoins;
$("profileCoins").textContent=userCoins;
$("settingsCoins").textContent=userCoins;

if($("requestWalletCoins"))
$("requestWalletCoins").textContent=userCoins;

}


function startWalletListener(){

const u=fxFirebase.user;
if(!u)return;

if(walletUnsubscribe)
walletUnsubscribe();

walletUnsubscribe=
onSnapshot(
doc(db,"users",u.uid),
snap=>{

if(!snap.exists())return;

const d=snap.data()||{};

updateWalletUI(
d.userName||
d.name||
u.displayName||
"FantasyXI User",
Number(d.coins??d.wallet??0)
);

if($("myReferralCode"))
$("myReferralCode").textContent=
d.referralCode||
makeReferralCode(u.uid);

},
e=>console.error("wallet:",e)
);

}


function cleanupListeners(){

[
matchUnsubscribe,
teamUnsubscribe,
statsUnsubscribe,
badgeUnsubscribe,
contestJoinUnsubscribe,
walletUnsubscribe
].forEach(x=>{
if(x)x();
});

matchUnsubscribe=null;
teamUnsubscribe=null;
statsUnsubscribe=null;
badgeUnsubscribe=null;
contestJoinUnsubscribe=null;
walletUnsubscribe=null;

}


/* MATCH */

function normalizeStatus(m){

const s=String(
m?.status||""
).trim().toLowerCase();

if(["complete","completed","finished"].includes(s))
return"finished";

if(["live","playing"].includes(s))
return"live";

return"upcoming";
}

function isLive(m){
return normalizeStatus(m)==="live";
}

function isUpcoming(m){
return normalizeStatus(m)==="upcoming";
}

function isFinished(m){
return normalizeStatus(m)==="finished";
}

function matchTitle(m){
return m?.name||
((m?.team1||"Team 1")+" vs "+(m?.team2||"Team 2"));
}


function subscribeMatches(){

if(matchUnsubscribe)
matchUnsubscribe();

matchUnsubscribe=
onSnapshot(
collection(db,"matches"),
snap=>{

matches=snap.docs.map(
d=>({id:d.id,...d.data()})
);

window.matchesReady=true;

renderMatches(currentMatchTab);
renderLive();

if(selectedMatch){
renderLiveScore();
loadContests(selectedMatch);
}

},
e=>{

console.error(e);

window.matchesReady=true;

$("matchList").innerHTML=
`<div class="card dangerText">
❌ Matches load হয়নি।
</div>`;

}
);

}


window.renderMatches=function(
tab="upcoming",
btn
){

currentMatchTab=tab;

if(btn){

document
.querySelectorAll("#matches .tabs button")
.forEach(x=>x.classList.remove("active"));

btn.classList.add("active");

}

const box=$("matchList");

if(!window.matchesReady){

box.innerHTML=
`<div class="card">
🔄 Firebase থেকে Matches load হচ্ছে...
</div>`;

return;
}

const arr=matches.filter(
m=>normalizeStatus(m)===tab
);

if(!arr.length){

box.innerHTML=
`<div class="empty">
📭 এই category-তে কোনো Match নেই।
</div>`;

return;
}

box.innerHTML=arr.map(m=>{

const st=normalizeStatus(m);

const action=
st==="upcoming"
?
`<button class="btn"
onclick="openCreateForMatch('${esc(m.id)}')">
Team →
</button>`
:
st==="live"
?
`<button class="btn"
onclick="openLive('${esc(m.id)}')">
Live →
</button>`
:
`<button class="btn"
onclick="openMatchLeaderboard('${esc(m.id)}')">
Leaderboard →
</button>`;

const info=
st==="live"
?
`<div class="small">
<span class="badge">LIVE</span>
${esc(m.score||"")}
</div>
<div class="small">
${esc(m.over||"")}${esc(m.event||"")}
</div>`
:
st==="upcoming"
?
`<div class="small">
🕒 ${esc(formatDate(
m.startTime??m.startAt??m.matchTime
))}
</div>`
:
`<div class="small">
🏁 Result completed
</div>`;

return`
<div class="match">

<div class="row">

<div class="grow">

<b>${esc(matchTitle(m))}</b>

${info}

</div>

${action}

</div>

${
st==="upcoming"
?
`<div class="row" style="margin-top:5px;gap:5px">
<button class="btn dark grow"
onclick="openContests('${esc(m.id)}')">
🏆 Contests
</button>
<button class="btn dark grow"
onclick="openMatchLeaderboard('${esc(m.id)}')">
🏆 Leaderboard
</button>
</div>`
: st==="finished"
?
`<button class="btn dark full"
onclick="openMatchLeaderboard('${esc(m.id)}')">
🏆 Leaderboard
</button>`
: ""
}

</div>
`;

}).join("");

};


function formatDate(v){

if(v==null||v==="")
return"Start time not set";

if(typeof v==="object"&&v.seconds)
return new Date(
Number(v.seconds)*1000
).toLocaleString("bn-BD");

const n=Number(v);

if(Number.isFinite(n))
return new Date(n).toLocaleString("bn-BD");

return String(v);
}


function getMatch(id){

return matches.find(
m=>String(m.id)===String(id)
);

}


/* CREATE / EDIT TEAM */

window.openCreateForMatch=async id=>{

const m=getMatch(id);

if(!m)
return toast("❌ Match পাওয়া যায়নি");

if(!isUpcoming(m))
return toast("🔒 এই Match এখন Team তৈরির জন্য বন্ধ");

selectedMatch=id;
editingTeamId=null; 
chosen=[];
cap=null;
vc=null;
$("teamName").value="";
$("createTeamTitle").textContent="👥 Create Team";

await loadMatchPlayers(id);

go("create");

};


async function loadMatchPlayers(matchId){

players=[];

$("players").innerHTML=
`<div class="card">
🔄 Firebase থেকে Players load হচ্ছে...
</div>`;

try{

const snap=await getDocs(
collection(db,"players")
);

const list=[];

snap.forEach(d=>{

const x=d.data()||{};

const mid=
x.matchId??
x.match??
"";

if(String(mid)!==String(matchId))
return;

const raw=
String(x.role||"")
.trim()
.toUpperCase();

let r=raw;

if(raw==="BAT"||raw==="BATTER")
r="BAT";

else if(
["AR","ALLROUNDER","ALL-ROUNDER","ALL ROUNDER"]
.includes(raw)
)
r="AR";

else if(
["WK","WICKETKEEPER","WICKET-KEEPER","WICKET KEEPER"]
.includes(raw)
)
r="WK";

else if(
["BOWL","BOWLER"].includes(raw)
)
r="BOWL";

list.push({

id:list.length+1,

firebaseId:d.id,

name:
x.name||
x.playerName||
d.id,

av:
x.av||
x.avatar||
"👤",

role:r,

price:Number(x.price??0)

});

});

players=list;

if(!editingTeamId) {
 chosen=[];
 cap=null;
 vc=null;
}
role="ALL";

renderPlayers();

$("selectedMatchName").textContent=
"🏏 "+matchTitle(getMatch(matchId)||{});

if(!players.length){

$("players").innerHTML=
`<div class="empty">
❌ এই Match-এর কোনো Player পাওয়া যায়নি।
</div>`;

return false;
}

toast("✅ "+players.length+" জন Player পাওয়া গেছে");

return true;

}catch(e){

console.error(e);

$("players").innerHTML=
`<div class="card dangerText">
❌ Player load হয়নি।
</div>`;

return false;
}

}


window.filterRole=(r,b)=>{

role=r;

document
.querySelectorAll(".filters button")
.forEach(x=>x.classList.remove("active"));

b.classList.add("active");

renderPlayers();

};


function renderPlayers(){

const box=$("players");

if(!box)return;

const list=players.filter(
p=>role==="ALL"||p.role===role
);

if(!list.length){

box.innerHTML=
`<div class="empty">
এই role-এ কোনো Player নেই।
</div>`;

return;
}

box.innerHTML=list.map(p=>{

const selected=
chosen.includes(p.id);

return`
<div class="player">

<div class="avatar">
${esc(p.av)}
</div>

<div class="grow">

<b>${esc(p.name)}</b>

<div class="pm">
${esc(p.role)} • ${p.price} Credits
</div>

</div>

<button
class="buy ${selected?"sel":""}"
onclick="togglePlayer(${p.id})">

${selected?"✓":"+"}

</button>

</div>
`;

}).join("");

$("cnt").textContent=chosen.length;

const spent=chosen.reduce(
(s,id)=>
s+
(players.find(p=>p.id===id)?.price||0),
0
);

$("credit").textContent=100-spent;

}


window.togglePlayer=id=>{

const i=chosen.indexOf(Number(id));

if(i>=0){

chosen.splice(i,1);

if(Number(cap)===Number(id))
cap=null;

if(Number(vc)===Number(id))
vc=null;

}else{

const p=players.find(
x=>x.id===Number(id)
);

if(!p)return;

const spent=chosen.reduce(
(s,x)=>
s+
(players.find(q=>q.id===x)?.price||0),
0
);

if(chosen.length>=11)
return toast("সর্বোচ্চ ১১ জন");

if(spent+p.price>100)
return toast("100 Credits-এর বেশি");

chosen.push(Number(id));

}

renderPlayers();

};


/* CAPTAIN */

window.goCV=()=>{

const teamName=
$("teamName").value.trim();

if(!teamName)
return toast("⚠️ আগে Team Name দিন");

if(chosen.length!==11)
return toast("⚠️ আগে ১১ জন Player নির্বাচন করুন");

const c=r=>
chosen.filter(
id=>players.find(p=>p.id===id)?.role===r
).length;

if(
c("BAT")!==5||
c("AR")!==2||
c("WK")!==1||
c("BOWL")!==3
)
return toast(
"⚠️ 5 BAT + 2 AR + 1 WK + 3 BOWL লাগবে"
);

if(!selectedMatch)
return toast("❌ Match selected নেই");

renderCV();

go("cv");

};


function renderCV(){

const box=$("cvList");

if(chosen.length!==11){

box.innerHTML=
`<div class="card">
⚠️ আগে ১১ জন Player নির্বাচন করুন
</div>`;

return;
}

box.innerHTML=

chosen.map(id=>{

const p=players.find(
x=>x.id===id
);

if(!p)return"";

return`
<div class="player">

<div class="avatar">
${esc(p.av)}
</div>

<div class="grow">

<b>${esc(p.name)}</b>

<div class="pm">
${esc(p.role)} • ${p.price} Credits
</div>

</div>

<button
class="buy ${Number(cap)===id?"sel":""}"
onclick="setC(${id})">

${Number(cap)===id?"✓ C":"C"}

</button>

<button
class="buy ${Number(vc)===id?"sel":""}"
onclick="setVC(${id})">

${Number(vc)===id?"✓ VC":"VC"}

</button>

</div>
`;

}).join("")+

`
<div class="captainInfo">

👑 Captain:
<b class="green">
${
esc(
cap
?
players.find(
x=>x.id===Number(cap)
)?.name
:
"নির্বাচন করুন"
)
}
</b>

<br>

⭐ Vice-Captain:
<b class="gold">
${
esc(
vc
?
players.find(
x=>x.id===Number(vc)
)?.name
:
"নির্বাচন করুন"
)
}
</b>

</div>
`;

}


window.setC=id=>{

if(!chosen.includes(Number(id)))
return;

if(Number(vc)===Number(id))
vc=null;

cap=
Number(cap)===Number(id)
?
null
:
Number(id);

renderCV();

};


window.setVC=id=>{

if(!chosen.includes(Number(id)))
return;

if(Number(cap)===Number(id))
cap=null;

vc=
Number(vc)===Number(id)
?
null
:
Number(id);

renderCV();

};


/* SAVE / UPDATE TEAM */

window.saveTeam=async()=>{

const m=getMatch(selectedMatch);

if(!m)
return toast("❌ Match পাওয়া যায়নি");

if(!isUpcoming(m))
return toast("🔒 Match Live/Finished — Team বন্ধ");

const teamName=
$("teamName").value.trim();

if(!teamName)
return toast("⚠️ Team Name দিন");

if(chosen.length!==11)
return toast("১১ জন Player নির্বাচন করুন");

if(cap===null||vc===null)
return toast(
"👑 Captain এবং ⭐ Vice-Captain নির্বাচন করুন"
);

if(Number(cap)===Number(vc))
return toast("C এবং VC আলাদা হতে হবে");

const u=fxFirebase.user;

if(!u)
return toast("❌ Login প্রয়োজন");


const team={

userId:u.uid,

email:u.email||"",

teamName:teamName,

name:teamName,

matchId:selectedMatch,

players:
chosen
.map(id=>
players.find(p=>p.id===id)?.firebaseId
)
.filter(Boolean),

playerIds:[...chosen],

playerNames:
chosen
.map(id=>
players.find(p=>p.id===id)?.name
)
.filter(Boolean),

captain:
players.find(
p=>p.id===Number(cap)
)?.firebaseId||"",

captainName:
players.find(
p=>p.id===Number(cap)
)?.name||"",

viceCaptain:
players.find(
p=>p.id===Number(vc)
)?.firebaseId||"",

viceCaptainName:
players.find(
p=>p.id===Number(vc)
)?.name||"",

updatedAt:serverTimestamp()

};


try{

if(editingTeamId) {
  await setDoc(doc(db, "teams", editingTeamId), team, { merge: true });
  toast("✅ Team Updated");
} else {
  team.createdAt = serverTimestamp();
  await addDoc(collection(db, "teams"), team);
  toast("✅ Team Firebase-এ Saved");
}

$("savedInfo").textContent=
`${teamName} • ${matchTitle(m)} • 11 Players • 👑 ${team.captainName} • ⭐ ${team.viceCaptainName}`;

chosen=[];
cap=null;
vc=null;
editingTeamId=null;

go("saved");

}catch(e){

console.error(e);

toast(
"❌ Team Save/Update হয়নি"
);

}

};


/* EDIT TEAM ACTION */

window.editTeam=async(teamId)=>{

const t=teams.find(x=>String(x.id)===String(teamId));

if(!t)
return toast("❌ Team পাওয়া যায়নি");

const m=getMatch(t.matchId||t.match);

if(!m)
return toast("❌ Match পাওয়া যায়নি");

if(!isUpcoming(m))
return toast("🔒 Match এখন Live বা Finished, Edit করা যাবে না");

editingTeamId=t.id;
selectedMatch=t.matchId||t.match;

$("teamName").value=t.teamName||t.name||"";
$("createTeamTitle").textContent="✏️ Edit Team";

const success = await loadMatchPlayers(selectedMatch);

if(success){

  if(t.playerIds && t.playerIds.length === 11) {
    chosen = [...t.playerIds];
  } else if(t.players && t.players.length === 11) {
    chosen = t.players.map(fid => {
      const p = players.find(x => String(x.firebaseId) === String(fid));
      return p ? p.id : null;
    }).filter(Boolean);
  }

  const cPlayer = players.find(x => String(x.firebaseId) === String(t.captain) || x.name === t.captainName);
  if(cPlayer) cap = cPlayer.id;

  const vcPlayer = players.find(x => String(x.firebaseId) === String(t.viceCaptain) || x.name === t.viceCaptainName);
  if(vcPlayer) vc = vcPlayer.id;

  renderPlayers();
  go("create");
  
}

};


/* TEAMS */

function subscribeTeams(){

const u=fxFirebase.user;

if(!u)return;

if(teamUnsubscribe)
teamUnsubscribe();

teamUnsubscribe=
onSnapshot(
collection(db,"teams"),
snap=>{

teams=snap.docs
.map(d=>({
id:d.id,
...d.data()
}))
.filter(
t=>
String(t.userId||"")===
String(u.uid)
);

renderTeams();

},
e=>console.error("teams:",e)
);

}


function renderTeams(){

const box=$("teams");

if(!box)return;

if(!teams.length){

box.innerHTML=
`<div class="empty">
এখনো কোনো Team তৈরি হয়নি।
</div>`;

return;
}

box.innerHTML=
teams.map((t,i)=>{

const m=getMatch(
t.matchId||t.match
);

const names=
t.playerNames||[];

const teamName=
t.teamName||
t.name||
"Team "+(i+1);

const canEdit = m ? isUpcoming(m) : false;

return`

<div class="card">

<div class="row">

<div class="grow">

<b>${esc(teamName)}</b>

<div class="small">
${esc(
m
?
matchTitle(m)
:
t.matchId||"Match"
)}
</div>

<div class="small">
👑 ${esc(t.captainName||"-")}
<br>
⭐ ${esc(t.viceCaptainName||"-")}
</div>

</div>

<div style="text-align:right">

<span class="statusPill">
${names.length||11} Players
</span>

${
canEdit
?
`<br><button class="btn dark" style="margin-top:6px;font-size:8px;" onclick="editTeam('${esc(t.id)}')">✏️ Edit Team</button>`
: ""
}

</div>

</div>

</div>
`;

}).join("");

}


window.createAnother=async()=>{

const m=matches.find(isUpcoming);

if(!m)
return toast("কোনো Upcoming Match নেই");

await openCreateForMatch(m.id);

};


/* CONTEST */

function contestMoney(c){
const entry=Number(c.entryCoins??c.entry??c.entryFee??c.entryPrice??0)||0;
const prize=Number(c.totalPrizeCoins??c.prizeCoins??c.totalPrize??c.prize??c.prizeMoney??0)||0;
return{entry,prize};
}

function contestStatus(c){

return[
"closed","inactive","disabled","finished"
].includes(
String(c.status??"active").trim().toLowerCase()
) ? "closed" : "active";

}


window.openContests=async matchId=>{

const m=getMatch(matchId);

if(!m)
return toast("❌ Match পাওয়া যায়নি");

if(!isUpcoming(m))
return toast("🔒 এই Match-এর Contest এখন বন্ধ");

selectedMatch=matchId;

$("contestMatchName").textContent=
"🏏 "+matchTitle(m);

go("contests");

await loadContests(matchId);

};


async function loadContests(matchId){

const box=$("contestList");

if(!box)return;

box.innerHTML=
`<div class="card">
🔄 Firebase থেকে Contest load হচ্ছে...
</div>`;

try{

const snap=
await getDocs(
collection(db,"contests")
);

contests=[];

snap.forEach(d=>{

const x=d.data()||{};

if(
String(x.matchId??x.match??x.matchID??"")
===
String(matchId)
)
contests.push({
id:d.id,
...x
});

});

renderContests();

subscribeContestJoins(matchId);

}catch(e){

console.error(e);

box.innerHTML=
`<div class="card dangerText">
❌ Contest load হয়নি।
</div>`;

}

}


function renderContests(){

const box=$("contestList");

if(!box)return;

const active=
contests.filter(
c=>contestStatus(c)==="active"
);

if(!active.length){

box.innerHTML=
`<div class="empty">
📭 এই Match-এর জন্য কোনো Contest নেই।
</div>`;

return;
}

box.innerHTML=
active.map(c=>{

const{entry,prize}=contestMoney(c);

const name=
c.name||
"Contest";

const joined=
joinedContestIds.includes(
String(c.id)
);

return`

<div class="contest">

<div class="contestTop">

<div class="contestIcon">
🏆
</div>

<div class="grow">

<div class="contestTitle">
${esc(name)}
</div>

<div class="contestLine">
💰 Entry:
<b>${entry}</b> Coins
</div>

<div class="contestLine">
🏆 Prize:
<b>${prize}</b> Coins
</div>

</div>

<button
class="btn contestJoin ${joined?"joined":""}"
onclick="joinContest('${esc(c.id)}')"
${joined?"disabled":""}>

${joined?"Joined":"Join"}

</button>

</div>

</div>

`;

}).join("");

}


function subscribeContestJoins(matchId){

if(contestJoinUnsubscribe)
contestJoinUnsubscribe();

const u=fxFirebase.user;

if(!u)return;

contestJoinUnsubscribe=
onSnapshot(
collection(db,"contestEntries"),
snap=>{

joinedContestIds=[];

snap.forEach(d=>{

const x=d.data()||{};

if(
String(x.userId)===
String(u.uid)&&
String(
x.matchId??x.match??""
)===
String(matchId)
)
joinedContestIds.push(
String(x.contestId||d.id)
);

});

renderContests();

},
e=>console.error("contestEntries:",e)
);

}


/* JOIN CONTEST */

window.joinContest=async contestId=>{

const u=fxFirebase.user;

if(!u)
return toast("❌ Login প্রয়োজন");

const c=
contests.find(
x=>String(x.id)===String(contestId)
);

if(!c)
return toast("❌ Contest পাওয়া যায়নি");

if(contestStatus(c)!=="active")
return toast("🔒 Contest বন্ধ");

const m=getMatch(selectedMatch);

if(!m)
return toast("❌ Match পাওয়া যায়নি");

if(!isUpcoming(m))
return toast("🔒 Match Live হয়ে গেছে");

if(joinedContestIds.includes(String(contestId)))
return toast("✅ আপনি ইতিমধ্যে Join করেছেন");


const myTeam=
teams.find(
t=>
String(t.userId)===
String(u.uid)&&
String(t.matchId||t.match)===
String(selectedMatch)
);

if(!myTeam)
return toast(
"⚠️ আগে Team তৈরি করুন এবং Team Name দিন"
);


const{entry,prize}=contestMoney(c);

const contestName=
c.name||"Contest";

const userRef=
doc(db,"users",u.uid);


try{

const result=
await runTransaction(
db,
async transaction=>{

const userSnap=
await transaction.get(userRef);

if(!userSnap.exists())
throw new Error("USER_NOT_FOUND");

const userData=
userSnap.data()||{};

const coins=
Number(
userData.coins??
userData.wallet??
0
);

if(coins<entry)
throw new Error(
"INSUFFICIENT_COINS"
);

const entryRef=
doc(collection(db,"contestEntries"));

transaction.update(
userRef,
{
coins:coins-entry,
updatedAt:serverTimestamp()
}
);

transaction.set(
entryRef,
{
contestId:String(contestId),
contestName,
matchId:String(selectedMatch),
matchName:matchTitle(m),
teamId:myTeam.id,
teamName:
myTeam.teamName||
myTeam.name||
"Team",
userId:u.uid,
userName:
userData.userName||
u.displayName||
"FantasyXI User",
email:u.email||"",
entry,
prize,
status:"joined",
createdAt:serverTimestamp(),
updatedAt:serverTimestamp()
}
);

return coins-entry;

}
);

joinedContestIds.push(
String(contestId)
);

updateWalletUI(
$("userName").value||
u.displayName||
"FantasyXI User",
result
);

renderContests();

toast(
`🏆 Contest Join সফল • ${entry} Coins কাটা হয়েছে`
);

}catch(e){

console.error(e);

if(e.message==="INSUFFICIENT_COINS")
return toast(
`❌ ${entry} Coins প্রয়োজন • আপনার পর্যাপ্ত Coins নেই`
);

if(e.message==="USER_NOT_FOUND")
return toast(
"❌ User Wallet পাওয়া যায়নি"
);

toast(
"❌ Join হয়নি"
);

}

};


/* PLAYER STATS */

function subscribePlayerStats(matchId){

if(statsUnsubscribe)
statsUnsubscribe();

playerStats={};

if(!matchId)
return;

statsUnsubscribe=
onSnapshot(
collection(db,"playerStats"),
snap=>{

playerStats={};

snap.forEach(d=>{

const x=d.data()||{};

const mid=
x.matchId??
x.statsMatchId??
x.match;

if(
String(mid)!==
String(matchId)
)
return;

const pid=
String(
x.playerId??
x.statsPlayerId??
d.id
);

playerStats[pid]={
...x,
id:d.id
};

if(x.playerName){

playerStats[
String(x.playerName)
]={
...x,
id:d.id
};

}

});

renderPoints();
renderLeaderboard();

},
e=>console.error(
"playerStats:",
e
)
);

}


/* POINT CALCULATION */

function calculatePoints(s){

if(!s)return 0;

return(
Number(s.runs||0)
+
Number(s.fours||0)*2
+
Number(s.sixes||0)*3
+
Number(
s.wickets||
s.wkts||
0
)*4
);

}


function statByPlayerId(playerId){

if(!playerId)
return{};

return playerStats[
String(playerId)
]||{};
}


/* TEAM POINT */

function playerMultiplier(
playerId,
playerName,
t
){

if(
String(playerId)===
String(t.captain)
||
String(playerName)===
String(t.captainName)
)
return 2;

if(
String(playerId)===
String(t.viceCaptain)
||
String(playerName)===
String(t.viceCaptainName)
)
return 1.5;

return 1;

}


function getTeamPlayerObjects(t){

const ids=t.playerIds||[];
const fids=t.players||[];
const names=t.playerNames||[];

return ids.map((id,index)=>{

const p=
players.find(
x=>Number(x.id)===Number(id)
);

const firebaseId=
p?.firebaseId||
fids[index]||
"";

const playerName=
p?.name||
names[index]||
"Player "+(index+1);

const avatar=
p?.av||
"👤";

const stats=
statByPlayerId(firebaseId);

const fallbackStats=
playerStats[String(playerName)]||{};

const finalStats=
Object.keys(stats).length
?
stats
:
fallbackStats;

const base=
calculatePoints(finalStats);

const mul=
playerMultiplier(
firebaseId,
playerName,
t
);

return{
id,
firebaseId,
name:playerName,
av:avatar,
stats:finalStats,
base,
multiplier:mul,
points:base*mul
};

});

}


function teamPoints(t){

let total=0;

const ids=
Array.isArray(t.playerIds)
?
t.playerIds
:
[];

const fids=
Array.isArray(t.players)
?
t.players
:
[];

const names=
Array.isArray(t.playerNames)
?
t.playerNames
:
[];

if(ids.length){

ids.forEach((id,index)=>{

const p=
players.find(
x=>Number(x.id)===Number(id)
);

const pid=
p?.firebaseId||
fids[index]||
"";

const pname=
p?.name||
names[index]||
"";

const stats=
statByPlayerId(pid);

const fallback=
playerStats[String(pname)]||{};

const s=
Object.keys(stats).length
?
stats
:
fallback;

const base=
calculatePoints(s);

const mul=
playerMultiplier(
pid,
pname,
t
);

total+=base*mul;

});

}else{

fids.forEach((pid,index)=>{

const pname=
names[index]||
"";

const s=
statByPlayerId(pid);

const fallback=
playerStats[String(pname)]||{};

const final=
Object.keys(s).length
?
s
:
fallback;

const base=
calculatePoints(final);

const mul=
playerMultiplier(
pid,
pname,
t
);

total+=base*mul;

});

}

return Number(
total.toFixed(1)
);

}

/* LIVE */

window.openLive=id=>{

const m=getMatch(id);

if(!m)
return toast("❌ Match পাওয়া যায়নি");

if(!isLive(m))
return toast("🔒 Match এখন Live নয়");

selectedMatch=id;

subscribePlayerStats(id);

renderLiveScore();

go("live");

loadLiveContests(id);

};


function renderLive(){

const b=$("liveList");

if(!b)return;

const arr=matches.filter(isLive);

b.innerHTML=
arr.length
?
arr.map(m=>`

<div class="livebox">

<div class="row">

<b>${esc(matchTitle(m))}</b>

<span class="badge">LIVE</span>

</div>

<div class="score">
${esc(m.score||"")}
</div>

<div class="small">
${esc(m.over||"")}
${esc(m.event||"")}
</div>

<button
class="btn full"
onclick="openLive('${esc(m.id)}')">

Live Score →

</button>

</div>

`).join("")
:
`<div class="empty">
এখন কোনো Match Live নেই।
</div>`;

}


async function loadLiveContests(matchId){

const box=$("liveContestList");

if(!box)return;

box.innerHTML=
`<div class="card">
🔄 Contest load হচ্ছে...
</div>`;

try{

const snap=await getDocs(
collection(db,"contests")
);

const list=[];

snap.forEach(d=>{

const c=d.data()||{};

const mid=c.matchId??c.match??"";

if(String(mid)!==String(matchId))
return;

if(contestStatus(c)==="closed")
return;

const money=contestMoney(c);

const name=
c.name??
c.contestName??
c.title??
`Contest ${list.length+1}`;

list.push({
id:d.id,
name,
prize:money.prize
});

});

if(!list.length){

box.innerHTML=
`<div class="empty">
📭 এই Live Match-এর কোনো Contest নেই।
</div>`;

return;

}

box.innerHTML=list.map(c=>`

<div class="card">

<div class="row">

<div class="grow">

<b>🏆 ${esc(c.name)}</b>

<div class="contestLine">
🏆 Prize:
<b>${c.prize}</b> Coins
</div>

</div>

<button
class="btn"
onclick="openContestLeaderboard('${esc(c.id)}')">

Leaderboard →

</button>

</div>

</div>

`).join("");

}catch(e){

console.error("Live Contest Error:",e);

box.innerHTML=
`<div class="card dangerText">
❌ Contest load হয়নি
</div>`;

}

}


function renderLiveScore(){

const b=$("liveScoreBox");

const m=getMatch(selectedMatch);

if(!m)
return b.innerHTML=
`<div class="card">
❌ Match পাওয়া যায়নি।
</div>`;

if(!isLive(m))
return b.innerHTML=
`<div class="card">
🔒 এই Match এখন Live নয়।
</div>`;

b.innerHTML=
`
<div class="liveScoreCard">

<span class="badge">LIVE</span>

<div class="score">
${esc(m.score||"")}
</div>

<div class="small">
${esc(matchTitle(m))}
</div>

<div class="small">
${esc(m.over||"")}
</div>

<div class="small">
${esc(m.event||"")}
</div>

</div>
`;

}

/* CURRENT USER TEAM */

function currentUserTeam(){

const u=fxFirebase.user;

return teams.find(
t=>
String(t.matchId||t.match)===
String(selectedMatch)&&
String(t.userId)===
String(u?.uid)
);

}


/* LIVE PLAYER POINTS */

function renderPoints(){

const b=$("pointBox");

if(!b)return;

const t=currentUserTeam();

if(!t){

b.innerHTML=
`<div class="empty">
এই Match-এ আপনার Team নেই।
</div>`;

return;
}


const list=
getTeamPlayerObjects(t);

if(!list.length){

b.innerHTML=
`<div class="empty">
Player পাওয়া যায়নি।
</div>`;

return;
}


b.innerHTML=

list.map((p,index)=>{

const s=p.stats||{};

const isC=p.multiplier===2;
const isVC=p.multiplier===1.5;

return`

<div class="pointLine">

<span>

${esc(p.av)}
${esc(p.name)}

${
isC
?
`<span class="mult">C 2×</span>`
:
isVC
?
`<span class="mult">VC 1.5×</span>`
:
""
}

<div class="small">
Runs ${Number(s.runs||0)}
•
4s ${Number(s.fours||0)}
•
6s ${Number(s.sixes||0)}
•
Wkts ${Number(s.wickets||s.wkts||0)}
</div>

</span>

<b class="green">
${p.points}
</b>

</div>

`;

}).join("")

+

`
<div class="card">

<b>
Total Fantasy Points:
<span class="green">
${teamPoints(t)}
</span>
</b>

</div>
`;

}



/* =====================================================
   LEADERBOARD (CONTEST AND MATCH SEPARATE)
   ===================================================== */

window.openMatchLeaderboard=async matchId=>{

selectedMatch=matchId;
window.selectedContest=null;

go("leaderboard");

await renderLeaderboard();

};

window.openContestLeaderboard=async contestId=>{

window.selectedContest=String(contestId);

if(!selectedMatch)
return toast("❌ Match পাওয়া যায়নি");

go("leaderboard");

await renderLeaderboard();

};

async function renderLeaderboard(){

const b=$("leaderBox");

if(!b)return;

if(!selectedMatch){

b.innerHTML=
`<div class="card">
❌ কোনো Match নির্বাচন করা হয়নি।
</div>`;

return;

}

b.innerHTML=
`<div class="card">
🔄 Leaderboard load হচ্ছে...
</div>`;

try{

const m=getMatch(selectedMatch);

let targetTeamIds=null;
let titleText=m?matchTitle(m):"Match Leaderboard";

if(window.selectedContest){

const entrySnap=await getDocs(collection(db,"contestEntries"));

const entries=entrySnap.docs
.map(d=>({id:d.id,...d.data()}))
.filter(e=>
String(e.matchId||e.match)===String(selectedMatch)&&
String(e.contestId)===String(window.selectedContest)&&
String(e.status||"joined").toLowerCase()!=="cancelled"
);

titleText=entries[0]?.contestName||"Contest Leaderboard";

if(!entries.length){

b.innerHTML=
`
<div class="card">

<div class="title">
🏆 ${esc(titleText)}
</div>

<div class="empty">
📭 এই Contest-এ এখনো কেউ Join করেনি।
</div>

</div>
`;

return;

}

targetTeamIds=new Set(entries.map(e=>String(e.teamId)));

}

const teamSnap=await getDocs(collection(db,"teams"));

let allTeams=teamSnap.docs
.map(d=>({id:d.id,...d.data()}))
.filter(t=>String(t.matchId||t.match)===String(selectedMatch));

if(targetTeamIds){

allTeams=allTeams.filter(t=>targetTeamIds.has(String(t.id)));

}

const board=allTeams.map(t=>({

...t,
total:teamPoints(t)

}));

board.sort((a,z)=>Number(z.total)-Number(a.total));

if(!board.length){

b.innerHTML=
`
<div class="card">

<div class="title">
🏆 ${esc(titleText)}
</div>

<div class="empty">
📭 এই Leaderboard-এ কোনো Team পাওয়া যায়নি।
</div>

</div>
`;

return;

}

const myUid=fxFirebase.user?.uid||"";

b.innerHTML=
`

<div class="card">

<div class="row">

<div class="grow">

<b>🏆 ${esc(titleText)}</b>

<div class="small">
${window.selectedContest?"🎯 Contest Specific Leaderboard":"🌐 Overall Match Leaderboard"}
</div>

</div>

<div style="text-align:right">

<b class="green">
${board.length}
</b>

<div class="small">
Teams
</div>

</div>

</div>

</div>

${
board.map((t,index)=>{

const teamName=
t.teamName||
t.name||
"Fantasy XI";

const isMine=
String(t.userId)===
String(myUid);

const playersList=
getTeamPlayerObjects(t);

const safeId=
"lb_team_"+String(t.id)
.replace(/[^a-zA-Z0-9_-]/g,"_");

return`

<div class="teamBoard">

<div class="teamBoardHead">

<div class="rank">
#${index+1}
</div>

<div class="grow">

<b>
${esc(teamName)}
</b>

${
isMine
?
`<span class="myTeamMark">MY TEAM</span>`
:
""
}

<div class="small">
${esc(
t.userName||
"FantasyXI User"
)}
</div>

</div>

<div style="text-align:right">

<b class="green">
${t.total}
</b>

<div class="small">
Points
</div>

</div>

</div>

<div style="padding:0 9px 7px">

<button
class="expandBtn"
onclick="toggleBoardTeam('${safeId}')">

👥 Players দেখুন / Hide

</button>

</div>

<div
id="${safeId}"
class="teamBoardBody hide">

${
playersList.length
?
playersList.map(p=>{

const s=p.stats||{};

return`

<div class="player">

<div class="avatar">
${esc(p.av||"👤")}
</div>

<div class="grow">

<b>
${esc(p.name)}
</b>

<div class="small">

${
p.multiplier===2
?
"👑 Captain • 2×"
:
p.multiplier===1.5
?
"⭐ Vice Captain • 1.5×"
:
"Player"
}

</div>

</div>

<div style="text-align:right">

<b class="green">
${Number(p.points).toFixed(1)}
</b>

<div class="small">
Points
</div>

</div>

</div>

`;

}).join("")

:

`<div class="empty">
📭 Player পাওয়া যায়নি।
</div>`
}

</div>

</div>

`;

}).join("")
}

`;

}catch(e){

console.error("Leaderboard Error:",e);

b.innerHTML=
`
<div class="card dangerText">

❌ Leaderboard load হয়নি।

</div>
`;

}

}


window.toggleBoardTeam=id=>{

const e=$(id);

if(!e)return;

e.classList.toggle("hide");

};


/* BADGES */

const badgeFeatures=[

{
id:1,
icon:"🥉",
name:"Bronze Badge",
cost:5000
},

{
id:2,
icon:"🥈",
name:"Silver Badge",
cost:10000
},

{
id:3,
icon:"🥇",
name:"Gold Badge",
cost:15000
},

{
id:4,
icon:"💎",
name:"Diamond Badge",
cost:30000
}

];


function renderBadgeCounts(){

const box=$("badgeCountGrid");

if(!box)return;

const counts=
window.__badgeCounts||
{1:0,2:0,3:0,4:0};

box.innerHTML=
badgeFeatures.map(b=>`

<div class="badgeCard">

<div class="badgeMini">
${b.icon}
</div>

<b>
${esc(
b.name.replace(" Badge","")
)}
</b>

<div class="badgeCount">
${counts[b.id]||0}
</div>

<div class="small">
Badge
</div>

</div>

`).join("");

}


function renderBadgeFeatures(){

const box=$("badgeFeatureGrid");

if(!box)return;

box.innerHTML=
badgeFeatures.map(x=>`

<div class="badgeCard">

<div class="badgeMini">
${x.icon}
</div>

<b>${esc(x.name)}</b>

<div class="badgeCost">
🪙 ${x.cost.toLocaleString()} Coins
</div>

<button
class="btn"
onclick="requestBadge(${x.id})">

Request

</button>

</div>

`).join("");

}


window.requestBadge=async id=>{

const b=
badgeFeatures.find(
x=>x.id===Number(id)
);

const u=fxFirebase.user;

if(!b)
return toast("❌ Badge পাওয়া যায়নি");

if(!u)
return toast("❌ Login প্রয়োজন");

requestBadgeId=b.id;

$("requestBadgeInfo").innerHTML=
`${b.icon}
<b>${b.name}</b>
<br>
<span class="small">
🪙 Cost:
${b.cost.toLocaleString()} Coins
</span>`;

try{

const s=
await getDoc(
doc(db,"users",u.uid)
);

const d=
s.exists()?
s.data()||{}:
{};

$("badgeRequestName").value=
d.userName||
d.name||
u.displayName||
"";

}catch(e){

$("badgeRequestName").value=
u.displayName||"";

}

$("badgeRequestPhone").value="";
$("badgeRequestError").textContent="";
$("requestWalletCoins").textContent=userCoins;

go("badgeRequest");

};


window.submitBadgeRequest=async()=>{

if(isSubmittingBadgeRequest) return;

const b=
badgeFeatures.find(
x=>x.id===Number(requestBadgeId)
);

const err=
$("badgeRequestError");

const u=fxFirebase.user;

if(!b){

err.textContent=
"❌ Badge নির্বাচন করুন";

return;
}

if(!u){

err.textContent=
"❌ Login প্রয়োজন";

return;
}

const inputName=
$("badgeRequestName").value.trim();

const phone=
$("badgeRequestPhone").value.trim();

if(!inputName){

err.textContent=
"❌ আপনার নাম দিন";

return;
}

if(!/^01\d{9}$/.test(phone)){

err.textContent=
"❌ সঠিক ১১ সংখ্যার ফোন নম্বর দিন";

return;
}

const btn = $("btnSubmitBadgeRequest");
isSubmittingBadgeRequest = true;
if(btn){
  btn.disabled = true;
  btn.textContent = "⏳ Request পাঠানো হচ্ছে...";
}

try{

const result=
await runTransaction(
db,
async transaction=>{

const userRef=
doc(db,"users",u.uid);

const userSnap=
await transaction.get(userRef);

if(!userSnap.exists())
throw new Error("USER_NOT_FOUND");

const userData=
userSnap.data()||{};

const coins=
Number(
userData.coins??
userData.wallet??
0
);

if(coins<b.cost)
throw new Error(
"INSUFFICIENT_COINS"
);

const requestRef=
doc(collection(db,"badgeRequests"));

transaction.update(
userRef,
{
userName:inputName,
phone,
coins:coins-b.cost,
updatedAt:serverTimestamp()
}
);

transaction.set(
requestRef,
{
badgeId:b.id,
badgeName:b.name,
cost:b.cost,
userId:u.uid,
userName:inputName,
phone,
email:u.email||"",
status:"pending",
createdAt:serverTimestamp(),
updatedAt:serverTimestamp()
}
);

return{
name:inputName,
coins:coins-b.cost
};

}
);

updateWalletUI(
result.name,
result.coins
);

toast(
`✅ ${b.name} Request পাঠানো হয়েছে • ${b.cost.toLocaleString()} Coins কাটা হয়েছে`
);

go("home");

}catch(e){

if(e.message==="INSUFFICIENT_COINS"){

err.textContent=
`❌ এই Badge-এর জন্য
${b.cost.toLocaleString()} Coins প্রয়োজন।`;

}else if(e.message==="USER_NOT_FOUND"){

err.textContent=
"❌ User Wallet পাওয়া যায়নি";

}else{

err.textContent=
"❌ Request Save হয়নি";

}

}finally{

isSubmittingBadgeRequest = false;
if(btn){
  btn.disabled = false;
  btn.textContent = "📤 Request পাঠান";
}

}

};

function startBadgeListener(){

if(badgeUnsubscribe)
badgeUnsubscribe();

const u=fxFirebase.user;

if(!u)return;


const badgeQuery=query(
collection(db,"badgeRequests"),
where("userId","==",u.uid)
);


badgeUnsubscribe=
onSnapshot(
badgeQuery,
snap=>{

const list=[];

const counts={
1:0,
2:0,
3:0,
4:0
};


snap.forEach(ds=>{

const d=ds.data()||{};

const st=String(
d.status||"pending"
)
.trim()
.toLowerCase();


list.push({
id:ds.id,
...d,
status:st
});


if(
st==="approved"||
st==="approve"||
d.approved===true
){

const bid=Number(d.badgeId);

if(
Object.prototype.hasOwnProperty.call(
counts,
bid
)
){

counts[bid]++;

}

}

});


window.__badgeCounts=counts;

renderBadgeCounts();


list.sort((a,b)=>{

const aTime=
a.updatedAt?.seconds||
a.createdAt?.seconds||
0;

const bTime=
b.updatedAt?.seconds||
b.createdAt?.seconds||
0;

return bTime-aTime;

});


const box=$("notificationList");

if(!box)return; 
  
if(!list.length){
  
box.innerHTML=
"কোনো নতুন Notification নেই।";

return;

}

box.innerHTML=
list.slice(0,3).map(d=>{

const st=String(
d.status||"pending"
)
.trim()
.toLowerCase();


let icon="⏳";

let text=
`${d.badgeName||"Badge"} Request Pending`;


if(
st==="approved"||
st==="approve"||
d.approved===true
){

icon="✅";

text=
`${d.badgeName||"Badge"} Approved`;

}


else if(
st==="rejected"||
st==="declined"||
st==="reject"
){

icon="❌";

text=
`${d.badgeName||"Badge"} Rejected`;

}


return`

<div
class="notification"
style="background:#123d31;border-color:#17604a">

${icon} ${esc(text)}

</div>

`;

}).join("");

},
e=>{

console.error(
"Badge Notification Error:",
e
);

const box=$("notificationList");

if(box){

box.innerHTML=
`<div class="notification dangerText">
❌ Badge Notification load হয়নি
</div>`;

}

}
);

}


/* SAVE PROFILE */

window.saveUser=async()=>{

const n=
$("userName").value.trim();

if(!n)
return toast("নাম লিখুন");

try{

await setDoc(
doc(db,"users",fxFirebase.user.uid),
{
userName:n,
email:fxFirebase.user.email||"",
updatedAt:serverTimestamp()
},
{merge:true}
);

try{
await updateProfile(
fxFirebase.user,
{displayName:n}
);
}catch(_){}

updateWalletUI(n,userCoins);

$("userStatus").textContent=
"✅ Profile saved";

toast("✅ Profile Saved");

}catch(e){

toast("❌ Profile Save হয়নি");

}

};


/* REFERRAL */

window.applyReferral=async()=>{

const u=fxFirebase.user;

const input=
$("referralInput").value
.trim()
.toUpperCase();

const status=
$("referralStatus");

if(!u)
return toast("❌ Login প্রয়োজন");

if(!input){

status.textContent=
"❌ Referral Code লিখুন";

return;
}

try{

const myRef=
doc(db,"users",u.uid);

const mySnap=
await getDoc(myRef);

if(!mySnap.exists()){

status.textContent=
"❌ User পাওয়া যায়নি";

return;
}

const myData=
mySnap.data()||{};

if(
myData.referralCompleted===true||
myData.referredBy
){

status.textContent=
"❌ আপনি ইতিমধ্যে Referral ব্যবহার করেছেন";

return;
}

if(
String(myData.referralCode||"")
.toUpperCase()===
input
){

status.textContent=
"❌ নিজের Referral Code ব্যবহার করা যাবে না";

return;
}

const usersSnap=
await getDocs(
collection(db,"users")
);

let referrer=null;

usersSnap.forEach(d=>{

const x=d.data()||{};

if(
String(x.referralCode||"")
.toUpperCase()===
input
)
referrer={
id:d.id,
data:x
};

});

if(!referrer){

status.textContent=
"❌ Referral Code সঠিক নয়";

return;
}

if(
String(referrer.id)===
String(u.uid)
){

status.textContent=
"❌ নিজের Referral Code ব্যবহার করা যাবে না";

return;
}

const referrerRef=
doc(db,"users",referrer.id);

const result=
await runTransaction(
db,
async transaction=>{

const newUserSnap=
await transaction.get(myRef);

const oldUserSnap=
await transaction.get(referrerRef);

if(
!newUserSnap.exists()||
!oldUserSnap.exists()
)
throw new Error(
"USER_NOT_FOUND"
);

const newUser=
newUserSnap.data()||{};

const oldUser=
oldUserSnap.data()||{};

if(
newUser.referralCompleted===true||
newUser.referredBy
)
throw new Error(
"ALREADY_USED"
);

const newCoins=
Number(
newUser.coins??
newUser.wallet??
0
)+100;

const oldCoins=
Number(
oldUser.coins??
oldUser.wallet??
0
)+100;

transaction.update(
myRef,
{
coins:newCoins,
referredBy:referrer.id,
referredByCode:input,
referralCompleted:true,
referralBonus:100,
referralCompletedAt:serverTimestamp(),
updatedAt:serverTimestamp()
}
);

transaction.update(
referrerRef,
{
coins:oldCoins,
referralCount:
Number(oldUser.referralCount||0)+1,
referralEarned:
Number(oldUser.referralEarned||0)+100,
updatedAt:serverTimestamp()
}
);

return{
coins:newCoins,
name:
newUser.userName||
newUser.name||
u.displayName||
"FantasyXI User"
};

}
);

updateWalletUI(
result.name,
result.coins
);

$("referralInput").value="";

status.textContent=
"✅ Referral সফল! আপনি 100 Coins পেয়েছেন।";

toast("🎉 Referral সফল • +100 Coins");

}catch(e){

console.error("Referral:",e);

if(e.message==="ALREADY_USED")
status.textContent=
"❌ Referral আগে ব্যবহার করা হয়েছে";

else if(e.message==="USER_NOT_FOUND")
status.textContent=
"❌ User পাওয়া যায়নি";

else
status.textContent=
"❌ Referral সফল হয়নি";

}

};


/* NAVIGATION */

window.go=function(id,nav){

document
.querySelectorAll(".page")
.forEach(x=>
x.classList.remove("active")
);

const e=$(id);

if(!e)return;

e.classList.add("active");

if(nav){

document
.querySelectorAll(".nav button")
.forEach(x=>
x.classList.remove("active")
);

nav.classList.add("active");

}

if(id==="matches")
renderMatches(currentMatchTab);

if(id==="create")
renderPlayers();

if(id==="cv")
renderCV();

if(id==="myteams")
renderTeams();

if(id==="live")
renderLive();

if(
id==="contests"&&
selectedMatch
)
loadContests(selectedMatch);

if(id==="livescore"){

subscribePlayerStats(selectedMatch);
renderLiveScore();

}

if(id==="points"){

subscribePlayerStats(selectedMatch);
renderPoints();

}

if(id==="leaderboard"){

subscribePlayerStats(selectedMatch);

setTimeout(
()=>renderLeaderboard(),
150
);

}

if(
id==="badgeRequest"&&
$("requestWalletCoins")
)
$("requestWalletCoins").textContent=
userCoins;

if(id==="home")
renderBadgeCounts();

window.scrollTo(0,0);

};

window.watchRewardAd = function(){

  const status = $("adRewardStatus");

  if(status){
    status.innerText =
      "📺 বিজ্ঞাপন লোড হচ্ছে...";
  }

  if(
    window.AndroidRewardAd &&
    typeof window.AndroidRewardAd.show === "function"
  ){

    window.AndroidRewardAd.show();

  }else{

    if(status){
      status.innerText =
        "❌ Rewarded Ad এখনো প্রস্তুত নয়";
    }

  }

};


/* ANDROID REWARD CALLBACK */

window.rewardAdCompleted = async function(){

  const status = $("adRewardStatus");

  const u = fxFirebase.user;

  if(!u){

    if(status){
      status.innerText =
        "❌ Login পাওয়া যায়নি";
    }

    return;

  }

  try{

    const ref = doc(
      db,
      "users",
      u.uid
    );

    const newCoins =
      await runTransaction(
        db,
        async(transaction)=>{

          const snap =
            await transaction.get(ref);

          const oldCoins =
            snap.exists()
            ?
            Number(
              snap.data().coins ?? 0
            )
            :
            0;

          const updatedCoins =
            oldCoins + 10;

          transaction.set(
            ref,
            {
              coins: updatedCoins,
              updatedAt: serverTimestamp()
            },
            {
              merge:true
            }
          );

          return updatedCoins;

        }
      );

    userCoins = newCoins;

    const name =
      u.displayName ||
      "FantasyXI User";

    updateWalletUI(
      name,
      userCoins
    );

    if(
      $("requestWalletCoins")
    ){

      $("requestWalletCoins")
        .textContent =
        userCoins;

    }

    if(status){

      status.innerText =
        "🎉 বিজ্ঞাপন দেখার জন্য +10 Coins যোগ হয়েছে!";

    }

  }catch(e){

    console.error(
      "Reward Coins:",
      e
    );

    if(status){

      status.innerText =
        "❌ Coins যোগ করা যায়নি";

    }

  }

};


/* INITIAL */

renderBadgeFeatures();
renderBadgeCounts();

$("matchList").innerHTML=
`<div class="card">
🔄 Firebase connecting...
</div>`;

$("contestList").innerHTML=
`<div class="card">
🏆 Match নির্বাচন করলে Contest দেখাবে...
</div>`;
