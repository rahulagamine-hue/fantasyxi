FantasyEleven package

Files:
- index.html
- style.css
- app.js
- app-icon.png

FantasyXI.apk was not supplied with the uploaded HTML, so it is not included.
The HTML was split into external CSS and JavaScript without intentionally changing
the Firebase configuration or application logic.
